<?php
return array(
'default' => array (
'hostname' => 'localhost','database' => 'yung','username' => 'root','password' => '7e8d85edf5','tablepre' => 'go_','charset' => 'utf8','type' => 'db_mysql','debug' => false,'pconnect' => 0,'autoconnect' => 0),
);